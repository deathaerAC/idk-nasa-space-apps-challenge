"""
Fetch a starter climate table for Earth analogue candidate sites using NASA POWER.
Install: pip install pandas requests
Run this script in the same folder as earth_candidate_sites.csv.

Output: nasa_power_climate_by_site.csv

Check the NASA POWER API documentation for current parameter names and metadata:
https://power.larc.nasa.gov/docs/services/api/
"""
import time
import requests
import pandas as pd

SITES_FILE = "earth_candidate_sites.csv"
OUTPUT_FILE = "nasa_power_climate_by_site.csv"
PARAMETERS = "T2M,T2M_MAX,T2M_MIN,PRECTOTCORR,RH2M,WS2M"

sites = pd.read_csv(SITES_FILE)
rows = []

for _, site in sites.iterrows():
    url = "https://power.larc.nasa.gov/api/temporal/climatology/point"
    params = {
        "parameters": PARAMETERS,
        "community": "AG",
        "longitude": float(site["longitude"]),
        "latitude": float(site["latitude"]),
        "format": "JSON",
    }
    response = requests.get(url, params=params, timeout=60)
    response.raise_for_status()
    payload = response.json()

    parameter_data = payload.get("properties", {}).get("parameter", {})
    units = payload.get("header", {}).get("parameters", {})

    row = {
        "site_name": site["site_name"],
        "latitude": site["latitude"],
        "longitude": site["longitude"],
        "environment_type": site["environment_type"],
        "target_body": site["target_body"],
        "source": "NASA POWER climatology point API",
        "api_url": response.url,
    }

    for parameter, monthly_values in parameter_data.items():
        for month, value in monthly_values.items():
            row[f"{parameter}_{month}"] = value
        row[f"{parameter}_unit"] = units.get(parameter, {}).get("units", "")

    rows.append(row)
    time.sleep(0.3)

pd.DataFrame(rows).to_csv(OUTPUT_FILE, index=False)
print(f"Saved {len(rows)} sites to {OUTPUT_FILE}")
