TERRESTRIAL ANALOG STARTER DATASET

Included:
1. earth_candidate_sites.csv - approximate representative coordinates for candidate Earth regions.
2. dataset_catalog.csv - suggested Earth, Moon and Mars datasets with official links.
3. fetch_nasa_power.py - retrieves climate values for the candidate points from the NASA POWER API.
4. nasa_power_climate_by_site.csv - generated after running the Python script.

IMPORTANT:
- Candidate coordinates are representative points, not surveyed boundaries.
- Candidate sites are not ranked, and no satellite measurements or suitability scores have been fabricated.
- NASA POWER data are gridded/model-assisted point estimates, not direct field-station measurements.
- Check units, quality flags, spatial coverage and product versions before analysis.
- SRTM does not cover the high polar latitudes; use an appropriate polar DEM for Arctic/Antarctic comparisons.
- Compare Earth, Moon and Mars terrain at harmonised spatial scales.

Suggested workflow:
1. Map earth_candidate_sites.csv in QGIS or Power BI.
2. Run fetch_nasa_power.py to create climate measurements.
3. Download MODIS NDVI/LST and suitable DEM layers for candidate-site buffers.
4. Derive slope, roughness, vegetation and thermal metrics.
5. Compare with lunar LOLA and Mars MOLA/CRISM reference data.
6. Label measured data, derived metrics, assumptions and gaps separately.
